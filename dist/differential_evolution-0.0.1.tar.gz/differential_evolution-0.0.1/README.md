# Differential Evolution

This is a simple project making a general interface for running differential evolution.
